// --- 1. Inisialisasi Peta ---
const map = L.map('map', {
    zoomControl: false
}).setView([-2.5489, 118.0149], 5);

// Pindahkan Zoom Control ke kanan atas
L.control.zoom({
    position: 'topright'
}).addTo(map);

// Tile Layer
const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '© OpenStreetMap contributors'
}).addTo(map);

// --- 2. Layers ---
const zonesLayer = L.layerGroup().addTo(map);
const markersLayer = L.layerGroup().addTo(map);
const routesLayer = L.layerGroup().addTo(map); // Layer untuk Rute Evakuasi

const overlayMaps = {
    "Zona Banjir": zonesLayer,
    "Titik Banjir": markersLayer,
    "Rute Evakuasi": routesLayer
};

L.control.layers(null, overlayMaps, { collapsed: false, position: 'topright' }).addTo(map);

// Legenda
const legend = L.control({ position: 'bottomright' });
legend.onAdd = function (map) {
    const div = L.DomUtil.create('div', 'info legend');
    div.innerHTML += '<h4>Legenda Risiko</h4>';
    div.innerHTML += '<div class="legend-item"><i class="legend-color" style="background: #ef4444;"></i> Risiko Tinggi</div>';
    div.innerHTML += '<div class="legend-item"><i class="legend-color" style="background: #f59e0b;"></i> Risiko Sedang</div>';
    div.innerHTML += '<div class="legend-item"><i class="legend-color" style="background: #10b981;"></i> Risiko Rendah</div>';
    return div;
};
legend.addTo(map);

// --- 3. State & Data ---
let allZones = [];
let allMarkers = [];

// --- 4. Fungsi Fetch Data & Logic ---

async function loadData() {
    try {
        // Fetch Zones
        const resZones = await fetch('data/zones.json');
        allZones = await resZones.json();
        renderZones(allZones);

        // Fetch Markers (Initial)
        await loadMarkers();

        // Update Statistics
        updateStats();

    } catch (error) {
        console.error("Error loading data:", error);
    }
}

function getPolygonCenter(coords) {
    // Simple centroid calc for visual center
    let latSum = 0, lngSum = 0, count = 0;
    coords.forEach(pt => {
        latSum += pt[0];
        lngSum += pt[1];
        count++;
    });
    return [latSum / count, lngSum / count];
}

function getNearestSafeZone(originCoords, city) {
    // Cari zona hijau di kota yang sama (atau terdekat secara global jika perlu)
    const greenZones = allZones.filter(z => z.riskLevel === 'Low' && (z.city === city || !city));

    let nearest = null;
    let minDist = Infinity;

    greenZones.forEach(zone => {
        const center = getPolygonCenter(zone.coords);
        const dist = Math.sqrt(
            Math.pow(center[0] - originCoords[0], 2) +
            Math.pow(center[1] - originCoords[1], 2)
        );
        if (dist < minDist) {
            minDist = dist;
            nearest = { zone, center };
        }
    });

    return nearest;
}

function renderZones(zones) {
    zonesLayer.clearLayers();
    zones.forEach(zone => {
        const polygon = L.polygon(zone.coords, {
            color: zone.color,
            fillColor: zone.color === 'red' ? '#ef4444' : zone.color === 'orange' ? '#f59e0b' : '#10b981',
            fillOpacity: 0.4,
            weight: 2
        }).bindPopup(zone.description).addTo(zonesLayer);

        // FITUR 2: EVACUATION ROUTE (Jika Zona Merah diklik)
        if (zone.riskLevel === 'High') {
            polygon.on('click', (e) => {
                const origin = getPolygonCenter(zone.coords);
                const safeZone = getNearestSafeZone(origin, zone.city);

                if (safeZone) {
                    // Gambar Garis Putus-putus
                    const routeLine = L.polyline([origin, safeZone.center], {
                        color: 'blue',
                        weight: 4,
                        opacity: 0.7,
                        dashArray: '10, 10',
                        lineCap: 'round'
                    }).addTo(routesLayer);

                    // Animasi FlyTo biar kelihatan rutenya
                    map.flyToBounds([origin, safeZone.center], { padding: [50, 50] });

                    // Popup info pada garis
                    routeLine.bindPopup(`
                        <strong>Rute Evakuasi</strong><br>
                        Menuju: ${safeZone.zone.name}<br>
                        <small>Ikuti jalur aman terdekat.</small>
                    `).openPopup();

                    // Hapus garis setelah beberapa detik (opsional, biar tidak penuh)
                    setTimeout(() => {
                        // routesLayer.removeLayer(routeLine); 
                        // User mungkin mau lihat dulu, jadi biar mereka close manual atau klik layer control
                    }, 10000);
                } else {
                    L.popup()
                        .setLatLng(e.latlng)
                        .setContent("Tidak ada zona aman terdata di dekat sini.")
                        .openOn(map);
                }
                L.DomEvent.stopPropagation(e); // Biar nggak trigger map click
            });
        }
    });
}

// Simulasi Data Real-time
function simulateRealTimeChanges(markers) {
    return markers.map(m => {
        const change = Math.floor(Math.random() * 11) - 5;
        let currentHeight = parseInt(m.height);
        let newHeight = Math.max(0, currentHeight + change);
        return { ...m, height: newHeight };
    });
}

async function loadMarkers() {
    try {
        const response = await fetch('data/markers.json');
        let data = await response.json();

        // Simulasi (jika belum ada data manual user)
        if (!window.userAddedMarkers) window.userAddedMarkers = [];

        // Gabung data simulasi dengan marker user
        if (window.simulatedMarkers) {
            window.simulatedMarkers = simulateRealTimeChanges(window.simulatedMarkers);
            allMarkers = [...window.simulatedMarkers, ...window.userAddedMarkers];
        } else {
            window.simulatedMarkers = data;
            allMarkers = [...data, ...window.userAddedMarkers];
        }

        renderMarkers(allMarkers);
        updateStatusTime();
        updateStats();

    } catch (error) {
        console.error("Gagal memuat markers:", error);
    }
}

function renderMarkers(markers) {
    markersLayer.clearLayers();
    markers.forEach(marker => {
        const m = L.marker([marker.lat, marker.lng])
            .bindPopup(`
                <strong>${marker.location}</strong><br>
                <small>${marker.city || 'Laporan Warga'}</small><br>
                <hr style="margin: 5px 0;">
                Ketinggian: <b>${marker.height} cm</b><br>
                <small>Updated: ${new Date().toLocaleTimeString()}</small>
            `);

        m.addTo(markersLayer);
    });
}

function updateStatusTime() {
    const el = document.getElementById('last-updated');
    if (el) el.innerText = new Date().toLocaleTimeString();
}

function updateStats() {
    const totalMarkers = allMarkers.length;
    const redZones = allZones.filter(z => z.riskLevel === 'High').length;

    document.getElementById('total-alerts').innerText = totalMarkers;
    document.getElementById('high-risk-zones').innerText = redZones;
    
    // Update alerts
    updateAlerts();
}

function updateAlerts() {
    const alertContent = document.getElementById('alert-content');
    const criticalMarkers = allMarkers.filter(m => m.height > 50);
    const warningMarkers = allMarkers.filter(m => m.height > 30 && m.height <= 50);
    
    let alertsHtml = '';
    
    // Critical alerts
    criticalMarkers.forEach(marker => {
        alertsHtml += `
            <div class="alert-item critical">
                <strong>KRITIS:</strong> ${marker.location} - ${marker.height}cm
            </div>
        `;
    });
    
    // Warning alerts
    warningMarkers.slice(0, 2).forEach(marker => {
        alertsHtml += `
            <div class="alert-item warning">
                <strong>WASPADA:</strong> ${marker.location} - ${marker.height}cm
            </div>
        `;
    });
    
    if (alertsHtml === '') {
        alertsHtml = '<div class="alert-item">Tidak ada peringatan saat ini</div>';
    }
    
    alertContent.innerHTML = alertsHtml;
}

// --- 5. Search & Interactivity ---

const searchInput = document.getElementById('city-search');
const resultsContainer = document.getElementById('city-results');

searchInput.addEventListener('input', (e) => {
    const query = e.target.value.toLowerCase();
    if (query.length < 2) {
        resultsContainer.innerHTML = '';
        return;
    }

    // Filter Kota unik dari Zones dan Markers
    const citiesFromZones = allZones.map(z => z.city);
    const citiesFromMarkers = allMarkers.map(m => m.city);
    const uniqueCities = [...new Set([...citiesFromZones, ...citiesFromMarkers])];
    const matchedCities = uniqueCities.filter(city => city && city.toLowerCase().includes(query));

    renderSearchResults(matchedCities);
});

function renderSearchResults(cities) {
    resultsContainer.innerHTML = '';
    cities.forEach(city => {
        const div = document.createElement('div');
        div.className = 'city-item';
        div.innerHTML = `
            <div>
                <h4>${city}</h4>
                <small>Lihat detail wilayah</small>
            </div>
            <i class="fa-solid fa-chevron-right" style="color:#cbd5e1"></i>
        `;
        div.addEventListener('click', () => flyToCity(city));
        resultsContainer.appendChild(div);
    });
}

function flyToCity(cityName) {
    const targetZone = allZones.find(z => z.city === cityName);
    const targetMarker = allMarkers.find(m => m.city === cityName);

    if (targetMarker) {
        map.flyTo([targetMarker.lat, targetMarker.lng], 13);
    } else if (targetZone && targetZone.coords.length > 0) {
        map.flyTo(targetZone.coords[0], 13);
    }
    searchInput.value = '';
    resultsContainer.innerHTML = '';
}

// --- 6. FITUR 1: LAPOR BANJIR (CROWDSOURCING) ---
let tempMarker = null;

map.on('click', function (e) {
    // Hapus tempMarker sebelumnya jika ada
    if (tempMarker) map.removeLayer(tempMarker);

    const popupContent = `
        <div class="report-form">
            <h4>📢 Lapor Banjir</h4>
            <input type="text" id="report-loc" placeholder="Nama Lokasi (Gedung/Jalan)">
            <input type="number" id="report-height" placeholder="Ketinggian Air (cm)">
            <button onclick="submitReport(${e.latlng.lat}, ${e.latlng.lng})">Kirim Laporan</button>
        </div>
    `;

    L.popup()
        .setLatLng(e.latlng)
        .setContent(popupContent)
        .openOn(map);
});

// Fungsi Global biar bisa dipanggil dari onclick di string HTML
window.submitReport = function (lat, lng) {
    const locName = document.getElementById('report-loc').value;
    const heightVal = document.getElementById('report-height').value;

    if (!locName || !heightVal) {
        alert("Mohon isi semua data!");
        return;
    }

    const newMarker = {
        id: Date.now(), // Unique ID based on timestamp
        location: locName,
        city: "Laporan Warga",
        lat: lat,
        lng: lng,
        date: new Date().toISOString().split('T')[0],
        height: heightVal
    };

    // Simpan ke state lokal (karena tidak ada backend beneran)
    if (!window.userAddedMarkers) window.userAddedMarkers = [];
    window.userAddedMarkers.push(newMarker);

    // Update marker layer langsung
    // (Akan otomatis kerender ulang di siklus polling berikutnya, 
    // tapi kita push manual biar instan feedback)
    allMarkers.push(newMarker);

    // Render Single Marker Langsung biar cepet
    L.marker([lat, lng])
        .bindPopup(`
            <strong>${locName}</strong><br>
            <small>Laporan Warga (Baru)</small><br>
            <hr style="margin: 5px 0;">
            Ketinggian: <b>${heightVal} cm</b><br>
            <small>Just Now</small>
        `)
        .addTo(markersLayer)
        .openPopup();

    map.closePopup(); // Tutup form
    updateStats(); // Update angka di sidebar
    alert("Laporan berhasil dikirim! Terima kasih.");
};

// --- 7. Init ---
loadData();
setInterval(loadMarkers, 5000);

// Mobile Sidebar Toggle
if (window.innerWidth <= 768) {
    const sidebar = document.querySelector('.sidebar');
    sidebar.addEventListener('click', (e) => {
        // Jangan close kalau klik input
        if (e.target.tagName !== 'INPUT') {
            sidebar.classList.toggle('active');
        }
    });
}
